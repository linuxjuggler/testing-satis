<?php

namespace App\Events;

class ExampleEvent extends Event
{
    /**
     * Create a new event instance.
     */
    public function __construct()
    {
    }
}
